/*
 * Utility functions for trap handling in Supervisor mode.
 */

#include "riscv.h"
#include "process.h"
#include "strap.h"
#include "syscall.h"
#include "pmm.h"
#include "vmm.h"
#include "sched.h"
#include "util/functions.h"

#include "spike_interface/spike_utils.h"

//
// handling the syscalls. will call do_syscall() defined in kernel/syscall.c
//
static void handle_syscall(trapframe *tf) {
  // tf->epc points to the address that our computer will jump to after the trap handling.
  // for a syscall, we should return to the NEXT instruction after its handling.
  // in RV64G, each instruction occupies exactly 32 bits (i.e., 4 Bytes)
  tf->epc += 4;
  long ret = do_syscall(
        tf->regs.a0,  // a0: 系统调用号
        tf->regs.a1,  // a1: 第一个参数（对于 SYS_user_print，是字符串地址）
        tf->regs.a2,  // a2: 第二个参数（对于 SYS_user_print，是字符串长度）
        tf->regs.a3,  // a3
        tf->regs.a4,  // a4
        tf->regs.a5,  // a5
        tf->regs.a6,  // a6
        tf->regs.a7   // a7
    );

    // 将系统调用的返回值设置回用户进程的 a0 寄存器
  tf->regs.a0 = ret;

}

//
// global variable that store the recorded "ticks". added @lab1_3
static uint64 g_ticks = 0;
//
// added @lab1_3
//
void handle_mtimer_trap() {
  sprint("Ticks %d\n", g_ticks);
  g_ticks++;
  write_csr(sip, read_csr(sip) & ~SIP_SSIP);

}

//
// the page fault handler. added @lab2_3. parameters:
// sepc: the pc when fault happens;
// stval: the virtual address that causes pagefault when being accessed.
//
void handle_user_page_fault(uint64 mcause, uint64 sepc, uint64 stval) {
  sprint("handle_page_fault: %lx\n", stval);
  switch (mcause) {
    case CAUSE_STORE_PAGE_FAULT:
    case CAUSE_LOAD_PAGE_FAULT:{
      uint64 fault_page = ROUNDDOWN(stval, PGSIZE);
      
      // 分配一个新的物理页面
      void *new_page = alloc_page();
      if (new_page == NULL) {
        sprint("handle_user_page_fault: alloc_page failed at va %p\n", stval);
        break;
      }
  
      // 将新物理页面映射到缺页的虚拟地址
      // 权限为可读可写（PROT_READ | PROT_WRITE），类型为用户页面（1）
      user_vm_map((pagetable_t)current->pagetable, fault_page, PGSIZE, 
                 (uint64)new_page, prot_to_type(PROT_READ | PROT_WRITE, 1));
      break;}
      
    default:
      sprint("unknown page fault.\n");
      break;
  }
}

//
// implements round-robin scheduling. added @lab3_3
//
void rrsched() {
  // TODO (lab3_3): implements round-robin scheduling.
  // hint: increase the tick_count member of current process by one, if it is bigger than
  // TIME_SLICE_LEN (means it has consumed its time slice), change its status into READY,
  // place it in the rear of ready queue, and finally schedule next process to run.
  if (current->tick_count + 1 >= TIME_SLICE_LEN) {
    // 2. 如果时间片用完：
    current->tick_count = 0;      // 重置当前进程的计数器
    current->status = READY;      // 设置为就绪态
    insert_to_ready_queue(current); // 放入就绪队列末尾
    schedule();                   // 调度下一个进程
  } else {
    // 3. 如果时间片还没用完：
    current->tick_count++;        // 仅仅增加计数，继续运行当前进程
  }

}

//
// kernel/smode_trap.S will pass control to smode_trap_handler, when a trap happens
// in S-mode.
//
void smode_trap_handler(void) {
  // make sure we are in User mode before entering the trap handling.
  // we will consider other previous case in lab1_3 (interrupt).
  if ((read_csr(sstatus) & SSTATUS_SPP) != 0) panic("usertrap: not from user mode");

  assert(current);
  // save user process counter.
  current->trapframe->epc = read_csr(sepc);

  // if the cause of trap is syscall from user application.
  // read_csr() and CAUSE_USER_ECALL are macros defined in kernel/riscv.h
  uint64 cause = read_csr(scause);

  // use switch-case instead of if-else, as there are many cases since lab2_3.
  switch (cause) {
    case CAUSE_USER_ECALL:
      handle_syscall(current->trapframe);
      break;
    case CAUSE_MTIMER_S_TRAP:
      handle_mtimer_trap();
      // invoke round-robin scheduler. added @lab3_3
      rrsched();
      break;
    case CAUSE_STORE_PAGE_FAULT:
    case CAUSE_LOAD_PAGE_FAULT:
      // the address of missing page is stored in stval
      // call handle_user_page_fault to process page faults
      handle_user_page_fault(cause, read_csr(sepc), read_csr(stval));
      break;
    default:
      sprint("smode_trap_handler(): unexpected scause %p\n", read_csr(scause));
      sprint("            sepc=%p stval=%p\n", read_csr(sepc), read_csr(stval));
      panic( "unexpected exception happened.\n" );
      break;
  }

  // continue (come back to) the execution of current process.
  switch_to(current);
}
